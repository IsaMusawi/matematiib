export interface DataModel {
    Title : string;
    Url : string;
    IsVideo: boolean;
}