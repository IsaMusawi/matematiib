import { Routes } from '@angular/router';
import { CollapsePaneComponent } from './collapse-pane/collapse-pane.component';

export const routes: Routes = [
    {path: '', component: CollapsePaneComponent},
];
